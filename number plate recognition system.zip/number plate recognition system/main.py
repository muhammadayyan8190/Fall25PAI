import cv2
import pytesseract
import imutils
import numpy as np

pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe"


def detect_plate(image_path):

    img = cv2.imread(image_path)

    if img is None:
        print("❌ Image not found")
        return

    print("✅ Image loaded successfully")

    img = imutils.resize(img, width=600)

    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    # better contrast
    gray = cv2.equalizeHist(gray)

    # detect edges softly
    blur = cv2.GaussianBlur(gray, (5, 5), 0)
    edged = cv2.Canny(blur, 50, 150)

    # ---------------- MORPHOLOGY (IMPORTANT FIX) ----------------
    kernel = np.ones((3, 3), np.uint8)
    morph = cv2.morphologyEx(edged, cv2.MORPH_CLOSE, kernel, iterations=2)

    # find contours
    cnts = cv2.findContours(morph.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    cnts = imutils.grab_contours(cnts)

    cnts = sorted(cnts, key=cv2.contourArea, reverse=True)

    plate_box = None
    plate_crop = None

    # ---------------- STRONGER PLATE DETECTION ----------------
    for c in cnts:

        x, y, w, h = cv2.boundingRect(c)

        aspect_ratio = w / float(h)
        area = w * h

        
        if 2 < aspect_ratio < 7 and area > 2000:

            plate_box = (x, y, w, h)
            plate_crop = gray[y:y+h, x:x+w]
            break

    if plate_crop is None:
        print("")
        cv2.imshow("Edges", edged)
        cv2.imshow("Morph", morph)
        cv2.imshow("Image", img)
        cv2.waitKey(0)
        cv2.destroyAllWindows()
        return

    x, y, w, h = plate_box
    cv2.rectangle(img, (x, y), (x+w, y+h), (0, 0, 255), 2)

    plate_crop = cv2.resize(plate_crop, None, fx=4, fy=4)

    plate_crop = cv2.GaussianBlur(plate_crop, (3, 3), 0)

    plate_crop = cv2.adaptiveThreshold(
        plate_crop,
        255,
        cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
        cv2.THRESH_BINARY,
        11,
        2
    )

    config = r'--oem 3 --psm 7'

    text = pytesseract.image_to_string(plate_crop, config=config)

    clean_text = "".join([c for c in text if c.isalnum()])

    print("\n🚗 Detected Number Plate:", clean_text if clean_text else "NOT READABLE")

    # ---------------- SHOW ----------------
    cv2.imshow("Plate", plate_crop)
    cv2.imshow("Detected Vehicle", img)

    cv2.waitKey(0)
    cv2.destroyAllWindows()


if __name__ == "__main__":
    detect_plate("images/car.webp")